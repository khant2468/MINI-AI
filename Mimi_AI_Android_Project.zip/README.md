# Mimi AI — Online Girlfriend Chatbot

ဒီ project က Android WebView app + online AI API အတွက် starter project ပါ။

## APK build
Android Studio နဲ့ project ကိုဖွင့်ပြီး Gradle Sync လုပ်ပါ။
ပြီးရင် Build > Build APK(s) ကိုရွေးပါ။

## Online AI
`app/src/main/assets/index.html` ထဲက `API_URL` ကို မင်းရဲ့ HTTPS server URL ပြောင်းပါ။

Server က POST `/chat` ကို `{ "message": "..." }` လက်ခံပြီး
`{ "reply": "..." }` ပြန်ပေးရပါမယ်။

API key ကို Android APK ထဲ မထည့်ပါနဲ့။ Server-side မှာပဲ သိမ်းပါ။
